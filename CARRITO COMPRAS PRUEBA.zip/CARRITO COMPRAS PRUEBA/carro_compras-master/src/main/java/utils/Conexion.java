package utils;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Conexion {

    // Declaración de variables para la conexión
    private static final String URL = "jdbc:mysql://localhost:3306/ejemplocarro?useTimezone=true&serverTimezone=UTC";
    private static final String USERNAME = "root";
    private static final String PASSWORD = "";

    // Bloque estático para cargar el controlador JDBC
    static {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver"); // Cargar el controlador JDBC para MySQL
        } catch (ClassNotFoundException e) {
            System.err.println("Error al cargar el controlador JDBC: " + e.getMessage());
        }
    }

    // Método para obtener la conexión
    public static Connection getConnection() throws SQLException {
        try {
            return DriverManager.getConnection(URL, USERNAME, PASSWORD);
        } catch (SQLException e) {
            System.err.println("Error al establecer la conexión: " + e.getMessage());
            throw e; // Relanzar la excepción para que sea manejada en niveles superiores
        }
    }
}
