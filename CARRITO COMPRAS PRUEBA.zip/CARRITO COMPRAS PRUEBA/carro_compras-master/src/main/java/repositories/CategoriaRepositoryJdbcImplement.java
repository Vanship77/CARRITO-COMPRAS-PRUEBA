package repositories;

import models.Categoria;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class CategoriaRepositoryJdbcImplement implements Repository<Categoria> {
    private Connection conn;

    public CategoriaRepositoryJdbcImplement(Connection conn) {
        this.conn = conn;
    }

    @Override
    public List<Categoria> listar() throws SQLException {
        List<Categoria> categorias = new ArrayList<>();
        try (Statement stmt = conn.createStatement(); ResultSet rs = stmt.executeQuery("SELECT * FROM categoria")) {
            while (rs.next()) {
                Categoria c = getCategoria(rs);
                categorias.add(c);
            }
        }
        return categorias;
    }

    @Override
    public Categoria porId(Long idCategoria) throws SQLException {
        Categoria categoria = null;
        try (PreparedStatement stmt = conn.prepareStatement("SELECT * FROM categoria WHERE idcategoria = ?")) {
            stmt.setLong(1, idCategoria);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    categoria = getCategoria(rs);
                }
            }
        }
        return categoria;
    }

    @Override
    public void guardar(Categoria categoria) throws SQLException {
        String sql;
        if (categoria.getIdCategoria() != null && categoria.getIdCategoria() > 0) {
            // Si tiene ID, es una actualización
            sql = "UPDATE categoria SET nombre = ?, estado = ? WHERE idcategoria = ?";
        } else {
            // Si no tiene ID, es una inserción
            sql = "INSERT INTO categoria (nombre, estado) VALUES (?, ?)";
        }

        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, categoria.getNombre());
            stmt.setInt(2, categoria.getEstado());

            if (categoria.getIdCategoria() != null && categoria.getIdCategoria() > 0) {
                stmt.setLong(3, categoria.getIdCategoria()); // Para la actualización
            }
            stmt.executeUpdate();
        }
    }

    @Override
    public void eliminar(Long id) throws SQLException {
        // Implementa la lógica para eliminar si lo necesitas
    }

    @Override
    public void invalidar(Categoria categoria) throws SQLException {
        // Primer paso: obtener el estado actual de la categoría
        String selectSql = "SELECT estado FROM categoria WHERE idcategoria = ?";
        try (PreparedStatement selectStmt = conn.prepareStatement(selectSql)) {
            selectStmt.setLong(1, categoria.getIdCategoria());
            ResultSet rs = selectStmt.executeQuery();

            // Si existe la categoría
            if (rs.next()) {
                int estadoActual = rs.getInt("estado");
                int nuevoEstado = (estadoActual == 0) ? 1 : 0; // Cambiar de 0 a 1 o de 1 a 0

                // Segundo paso: actualizar el estado con el valor opuesto
                String updateSql = "UPDATE categoria SET estado = ? WHERE idcategoria = ?";
                try (PreparedStatement updateStmt = conn.prepareStatement(updateSql)) {
                    updateStmt.setInt(1, nuevoEstado);
                    updateStmt.setLong(2, categoria.getIdCategoria());
                    updateStmt.executeUpdate();
                }
            }
        }
    }

    @Override
    public void actualizar(Categoria categoria) throws SQLException {

    }


    private static Categoria getCategoria(ResultSet rs) throws SQLException {
        Categoria c = new Categoria();
        c.setIdCategoria(rs.getLong("idcategoria"));
        c.setNombre(rs.getString("nombre"));
        c.setEstado(rs.getInt("estado"));
        return c;
    }

}