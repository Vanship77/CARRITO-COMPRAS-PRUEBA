package controllers;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import models.Categoria;
import models.Productos;
import service.CategoriaService;
import service.CategoriaServiceJdbcImplement;
import service.ProductoService;
import service.ProductoServiceJdbcImplement;

import java.io.IOException;
import java.sql.Connection;
import java.util.Optional;

@WebServlet("/categorias/form")
public class CategoriaFromControlador extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        // Recuperamos la conexión
        Connection conn = (Connection) req.getAttribute("conn");
        CategoriaService services = new CategoriaServiceJdbcImplement(conn);

        // Recuperamos el ID de la categoría para editar (si existe)
        long id = 0L;
        try {
            // Recogemos el parámetro 'idCategoria' de la URL
            id = Long.parseLong(req.getParameter("idCategoria"));
        } catch (NumberFormatException e) {
            // Si no existe o no es válido, lo dejamos en 0L
        }

        // Si existe un id válido, obtenemos la categoría para editar
        Categoria categoria = new Categoria();
        if (id > 0) {
            Optional<Categoria> o = services.porIdCategoria(id);
            if (o.isPresent()) {
                categoria = o.get();
            }
        }

        // Si no se encuentra la categoría, la dejamos en blanco para crear
        req.setAttribute("categoria", categoria);
        getServletContext().getRequestDispatcher("/formularioCategoria.jsp").forward(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        // Obtenemos la conexión y el servicio
        Connection conn = (Connection) req.getAttribute("conn");
        CategoriaService service = new CategoriaServiceJdbcImplement(conn);

        // Recuperamos los parámetros del formulario
        String nombre = req.getParameter("nombre");
        int estado = 1;  // Por defecto "Activo"

        // Recuperamos el ID de la categoría (si es edición)
        Long idCategoria = 0L;
        try {
            idCategoria = Long.valueOf(req.getParameter("idCategoria"));
        } catch (NumberFormatException e) {
            idCategoria = 0L;
        }


        // Creamos o actualizamos la categoría
        Categoria categoria = new Categoria();
        categoria.setIdCategoria(idCategoria);
        categoria.setNombre(nombre);
        categoria.setEstado(estado);

        // Guardamos la categoría (insertar o actualizar según el caso)
        service.guardar(categoria);

        // Redireccionamos para evitar reenvíos del formulario
        resp.sendRedirect(req.getContextPath() + "/categorias");
    }
}

