package controllers;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import service.ProductoService;
import service.ProductoServiceJdbcImplement;

import java.io.IOException;
import java.sql.Connection;

@WebServlet("/productos/eliminar")
public class ProductosControladorEliminar extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        //necesitamos la conexion
        Connection conn = (Connection) req.getAttribute("conn");
        ProductoService service = new ProductoServiceJdbcImplement(conn);

        long idProducto;
        try {
            idProducto = Long.parseLong(req.getParameter("idProducto"));
        } catch (NumberFormatException e) {
            idProducto = 0L;
        }
        if (idProducto > 0) {
            service.eliminar(idProducto);
        }
        resp.sendRedirect(req.getContextPath() + "/productos");
    }
}
