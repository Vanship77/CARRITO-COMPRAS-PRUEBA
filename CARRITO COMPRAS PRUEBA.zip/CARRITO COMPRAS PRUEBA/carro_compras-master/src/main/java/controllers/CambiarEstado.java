package controllers;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import models.Categoria;
import repositories.CategoriaRepositoryJdbcImplement;
import utils.Conexion;

import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;

@WebServlet("/categorias/inavilitar")
public class CambiarEstado extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Obtener el id de la categoría desde el parámetro de la solicitud
        String idCategoriaParam = request.getParameter("idCategoria");

        if (idCategoriaParam != null && !idCategoriaParam.isEmpty()) {
            try {
                Long idCategoria = Long.parseLong(idCategoriaParam);

                // Obtener la conexión a la base de datos (puedes obtenerla de una clase utilitaria)
                Connection conn = Conexion.getConnection();  // Asegúrate de que esta clase esté bien configurada

                // Crear el repositorio y usarlo
                CategoriaRepositoryJdbcImplement categoriaRepository = new CategoriaRepositoryJdbcImplement(conn);
                // Obtener la categoría por su ID
                Categoria categoria = categoriaRepository.porId(idCategoria);

                if (categoria != null) {
                    // Llamar al método invalidar del repositorio para cambiar su estado
                    categoriaRepository.invalidar(categoria);

                    // Redirigir a la lista de categorías después de la operación
                    response.sendRedirect(request.getContextPath() + "/categorias");
                } else {
                    // Si la categoría no se encuentra
                    request.setAttribute("error", "Categoría no encontrada.");
                    request.getRequestDispatcher("/error.jsp").forward(request, response);
                }
            } catch (SQLException e) {
                e.printStackTrace();
                request.setAttribute("error", "Error al actualizar el estado de la categoría.");
                request.getRequestDispatcher("/error.jsp").forward(request, response);
            }
        } else {
            // Si el parámetro idCategoria no es válido, redirigir a la lista
            response.sendRedirect(request.getContextPath() + "/categorias");
        }
    }
}
