package service;

import models.Categoria;
import repositories.CategoriaRepositoryJdbcImplement;
import repositories.Repository;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;
import java.util.Optional;

public class CategoriaServiceJdbcImplement implements CategoriaService {

    private Repository<Categoria> repositoryCategoriaJdbc;

    public CategoriaServiceJdbcImplement(Connection connection) {
        this.repositoryCategoriaJdbc = new CategoriaRepositoryJdbcImplement(connection);
    }

    @Override
    public void guardar(Categoria categoria) {
        try {
            repositoryCategoriaJdbc.guardar(categoria);
        } catch (SQLException throwables) {
            throw new ServiceJdbcException(throwables.getMessage(),throwables.getCause());
        }
    }

    @Override
    public List<Categoria> listarCategoria() {
        try {
            return repositoryCategoriaJdbc.listar();
        } catch (SQLException throwables) {
            throw new ServiceJdbcException(throwables.getMessage(),throwables.getCause());
        }
    }



    @Override
    public Optional<Categoria> porIdCategoria(Long idCategoria) {
        try {
            return Optional.ofNullable(repositoryCategoriaJdbc.porId(idCategoria));
        } catch (SQLException throwables) {
            throw new ServiceJdbcException(throwables.getMessage(), throwables.getCause());
        }
    }



}
