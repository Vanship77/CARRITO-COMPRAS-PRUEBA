package service;

import models.Categoria;

import java.util.List;
import java.util.Optional;

public interface CategoriaService {



    void guardar(Categoria categoria);
    List<Categoria> listarCategoria();
    Optional<Categoria> porIdCategoria(Long idCategoria);
}
